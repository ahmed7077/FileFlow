package com.dsafileorganiser;

import com.dsafileorganiser.cli.CommandLineOptions;
import com.dsafileorganiser.organiser.JavaCodeOrganiser;
import com.dsafileorganiser.organiser.OrganisationSummary;

public final class DsaFileOrganiserApplication {
    private DsaFileOrganiserApplication() {
    }

    public static void main(String[] args) {
        try {
            CommandLineOptions options = CommandLineOptions.parse(args);
            OrganisationSummary summary = new JavaCodeOrganiser().organise(
                    options.inputPath(),
                    options.outputZipPath(),
                    options.removeCommentsForDuplicateCheck()
            );

            System.out.println("Organisation complete.");
            System.out.println("Java files scanned: " + summary.scannedFileCount());
            System.out.println("Unique files kept: " + summary.uniqueFileCount());
            System.out.println("Duplicate files removed: " + summary.duplicateFileCount());
            System.out.println("Downloadable ZIP: " + summary.outputZipPath());
        } catch (IllegalArgumentException exception) {
            System.err.println(exception.getMessage());
            CommandLineOptions.printUsage();
            System.exit(1);
        } catch (Exception exception) {
            System.err.println("Failed to organise Java files: " + exception.getMessage());
            exception.printStackTrace(System.err);
            System.exit(2);
        }
    }
}
